package ch.zli.m223.crm.controller.rest.dto;

/**
 * Input DTO for an memi of a customer
 */
public class MemoInputDto {
	public String memo;
}
