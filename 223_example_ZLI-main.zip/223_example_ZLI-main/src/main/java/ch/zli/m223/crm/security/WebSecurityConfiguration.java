package ch.zli.m223.crm.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class WebSecurityConfiguration{


	@Autowired
	UserDetailsService userDetailsService;

	@Bean
	// Configure HTTP Security
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

		http
				// Since REST is state-less we need no session management
				.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
				// REST is not compatible with csrf()
				.csrf().disable()
				// We need a cors-policy, use a default one here
				.cors()
				.and()
				// Let's send username password on each call
				.httpBasic();


		http.authorizeHttpRequests((authorizeHttp)->authorizeHttp.antMatchers(HttpMethod.POST, "/api/v0/users")
						.hasAuthority("admin")

						// Admin and User should be able to see the user list
						.antMatchers(HttpMethod.GET, "/api/v0/users")
						.hasAnyAuthority("admin", "user")

						// /users/{user_id}
						// ----------------
						// Admin should be able to delete users
						.antMatchers(HttpMethod.DELETE, "/api/v0/users/{user_id}")
						.hasAuthority("admin")

						// Admin and User should be able to see a user
						.antMatchers(HttpMethod.GET, "/api/v0/users/{user_id}")
						.hasAnyAuthority("admin", "user")

						//WEB users
						.antMatchers("/", "/users/**").permitAll()
						.anyRequest().authenticated());
		return http.build();
	}

	@Bean
	// Configure authentication provider
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();

		authProvider.setUserDetailsService(userDetailsService);
		authProvider.setPasswordEncoder(new BCryptPasswordEncoder());

		return authProvider;
	}
}
