package ch.zli.m223.crm.controller.rest.dto;

/**
 * This is the InputDTO to add an new user with post
 */
public class UserInputDto {

	public String email;
	public String password;

}
