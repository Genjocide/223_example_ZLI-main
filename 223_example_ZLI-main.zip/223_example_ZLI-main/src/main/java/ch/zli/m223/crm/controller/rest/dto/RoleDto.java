package ch.zli.m223.crm.controller.rest.dto;

import ch.zli.m223.crm.model.Role;

public class RoleDto {
	public Long id;
	public String role_name;

	public RoleDto(Role role) {
		id = role.getId();
		this.role_name = role.getRole();
	}
}
