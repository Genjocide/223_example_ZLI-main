package ch.zli.m223.crm.controller.rest.dto;

/**
 * This is the InputDTO to add an new customer with post
 */
public class CustomerInputDto {

	public String name;
	public String street;
	public String city;
	
}
