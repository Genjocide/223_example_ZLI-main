package ch.zli.m223.crm.role;

public interface Roles {
	public final String USER = "user";
	public final String ADMIN = "admin";
}
