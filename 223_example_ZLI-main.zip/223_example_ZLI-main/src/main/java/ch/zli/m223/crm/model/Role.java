package ch.zli.m223.crm.model;

public interface Role {
	Long getId();
	
	String getRole();
}
