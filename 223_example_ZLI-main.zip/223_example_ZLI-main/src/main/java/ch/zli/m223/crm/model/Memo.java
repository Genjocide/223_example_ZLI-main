package ch.zli.m223.crm.model;

import java.util.Date;

public interface Memo {
	Long getId();
	
	String getMemo();
	
	Date getDate();
}
