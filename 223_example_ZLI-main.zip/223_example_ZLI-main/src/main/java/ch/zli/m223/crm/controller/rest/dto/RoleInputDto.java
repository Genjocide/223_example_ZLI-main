package ch.zli.m223.crm.controller.rest.dto;

public class RoleInputDto {
	public Long id;
	public String rolename;
}
