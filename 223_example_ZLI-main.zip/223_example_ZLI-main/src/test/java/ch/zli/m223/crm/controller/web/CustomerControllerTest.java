package ch.zli.m223.crm.controller.web;

import ch.zli.m223.crm.model.Customer;
import ch.zli.m223.crm.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {

    @Mock
    private CustomerService customerService;

    @InjectMocks
    private CustomerController customerController;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(customerController).build();
    }

    @Test
    public void test_getAllCustomers() throws Exception {
        when(customerService.getAllCustomers()).thenReturn(new ArrayList<>());
        mockMvc.perform(get("/web/customers/customer_list")); // .andDo(print()); for analysis purposes
        verify(customerService).getAllCustomers();
    }

    @Test
    public void test_getOneCustomerById() throws Exception {
        final long id = 42;
        when(customerService.getCustomerById(id)).thenReturn(mock(Customer.class));
        mockMvc.perform(get("/web/customers/" + id)); // .andDo(print()); for analysis purposes
        verify(customerService).getCustomerById(id);
    }

    @Test
    public void test_deleteCustomer() throws Exception {
        final long id = 69;
        mockMvc.perform(get("/web/customers/admin/" + id + "/delete"));
        verify(customerService).deleteById(id);
    }

    @Test
    public void test_addAnUser() throws Exception {
        final long customerId = 101;
        final Customer customer = mock(Customer.class);
        when(customerService.addCustomer(anyString(),anyString(),anyString())).thenReturn(customer);
        when(customer.getId()).thenReturn(customerId);
        mockMvc.perform(post("/web/customers/addcustomer")
                .param("name","name")
                .param("street", "street")
                .param("city", "city")
                .param("memo","memo"));
        verify(customerService).addCustomer("name", "street", "city");
        verify(customerService).setMemosForCustomer(customerId,"memo");
    }
}

