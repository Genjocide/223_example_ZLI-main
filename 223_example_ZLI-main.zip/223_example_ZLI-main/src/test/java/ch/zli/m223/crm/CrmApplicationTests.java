package ch.zli.m223.crm;

import ch.zli.m223.crm.model.Customer;
import io.restassured.RestAssured;
import io.restassured.authentication.FormAuthConfig;
import io.restassured.filter.session.SessionFilter;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static io.restassured.RestAssured.*;
import static io.restassured.authentication.FormAuthConfig.springSecurity;

@SpringBootTest
class CrmApplicationTests {

	@Test
	void test_getAllCustomers() {
		RestAssured.baseURI = "http://localhost:8080";

		SessionFilter sessionFilter = new SessionFilter();

		given().
				auth().form("admin", "admin", springSecurity()).
				filter(sessionFilter).
				when().
				get("/index");

		given().
				filter(sessionFilter).
				when().
				get("/api/v0/customers").
				then().
				statusCode(200);

	}
}
